See "Getting Started - Using the Device - USB Device - Bootloaders.html" file.
It should be located in the "<Install Directory>\Microchip\USB\Documentation\Getting Started"

===========================================================================================

The HIDBootloader.exe program was written in Microsoft Visual C++ 2005 Express Edition.

Therefore, in order to use this program, you will need to have the .NET framework version 2.0
(higher version probably okay, although not tested) installed on your computer.  If you do
not have the .NET framework 2.0 installed, a non-descript error message will occur when trying to 
launch the executable, and the program will not open.  You may also need to install the 
Microsoft Visual C++ 2005 Redistributeable Package.

You may already have the .NET framework installed on your PC, especially if you have already installed
other applications which were built with one of the Visual Studio 2005 .NET languages.  If you do not
yet have it, the .NET framework can be freely downloaded from Microsoft's website.  Users of Windows Vista
do not need to install the .NET framework, as it comes pre-installed as part of the OS.

The redistributables are currently (22 May 2008) available at:
http://www.microsoft.com/downloads/details.aspx?FamilyID=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5&displaylang=en
http://www.microsoft.com/downloads/details.aspx?familyid=32bc1bee-a3f9-4c13-9c99-220b62a191ee&displaylang=en
